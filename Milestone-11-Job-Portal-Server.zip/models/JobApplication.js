const { client } = require("../config/dbConnection");

const jobApplicationCollection = client
  .db("jobWave")
  .collection("jobApplications");

// Create job application
const createJobApplication = async (applicationData) => {
  try {
    return await jobApplicationCollection.insertOne(applicationData);
  } catch (error) {
    console.error("Error in createJobApplication model:", error);
    throw error;
  }
};

// Get applications by user
const getApplicationsByUser = async (userId) => {
  try {
    const query = { userId: userId };
    const cursor = jobApplicationCollection.find(query);
    return await cursor.toArray();
  } catch (error) {
    console.error("Error in getApplicationsByUser model:", error);
    throw error;
  }
};

// Get applications by job
const getApplicationsByJob = async (jobId) => {
  try {
    const query = { jobId: jobId };
    const cursor = jobApplicationCollection.find(query);
    return await cursor.toArray();
  } catch (error) {
    console.error("Error in getApplicationsByJob model:", error);
    throw error;
  }
};

module.exports = {
  createJobApplication,
  getApplicationsByUser,
  getApplicationsByJob,
};
