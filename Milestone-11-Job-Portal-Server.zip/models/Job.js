const { ObjectId } = require("mongodb");
const { client } = require("../config/dbConnection");

const jobCollection = client.db("jobWave").collection("jobs");

// Get all jobs
const getAllJobs = async () => {
  try {
    const cursor = jobCollection.find();
    return await cursor.toArray();
  } catch (error) {
    console.error("Error in getAllJobs model:", error);
    throw error;
  }
};

// Get job by ID
const getJobById = async (id) => {
  try {
    const query = { _id: new ObjectId(id) };
    return await jobCollection.findOne(query);
  } catch (error) {
    console.error("Error in getJobById model:", error);
    throw error;
  }
};

// Create new job
const createJob = async (jobData) => {
  try {
    return await jobCollection.insertOne(jobData);
  } catch (error) {
    console.error("Error in createJob model:", error);
    throw error;
  }
};

// Additional functions can be added as needed for updating and deleting jobs

module.exports = {
  getAllJobs,
  getJobById,
  createJob,
};
