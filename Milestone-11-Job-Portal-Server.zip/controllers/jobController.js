const Job = require("../models/Job");

// Get all jobs
const getAllJobs = async (req, res) => {
  try {
    const jobs = await Job.getAllJobs();
    res.send(jobs);
  } catch (error) {
    console.error("Error fetching jobs:", error);
    res.status(500).send("Error fetching jobs");
  }
};

// Get job by ID
const getJobById = async (req, res) => {
  try {
    const id = req.params.id;
    const job = await Job.getJobById(id);

    if (!job) {
      return res.status(404).send("Job not found");
    }

    res.send(job);
  } catch (error) {
    console.error("Error fetching job details:", error);
    res.status(500).send("Error fetching job details");
  }
};

// Create new job
const createJob = async (req, res) => {
  try {
    const jobData = req.body;
    const result = await Job.createJob(jobData);
    res.status(201).send(result);
  } catch (error) {
    console.error("Error creating job:", error);
    res.status(500).send("Error creating job");
  }
};

module.exports = {
  getAllJobs,
  getJobById,
  createJob,
};
