const JobApplication = require("../models/JobApplication");

// Create job application
const createJobApplication = async (req, res) => {
  try {
    const applicationData = req.body;
    console.log(applicationData);

    const result = await JobApplication.createJobApplication(applicationData);
    console.log(result);

    res.send(result);
  } catch (error) {
    console.error("Error processing job application:", error);
    res.status(500).send("Error processing job application");
  }
};

// Get applications by user
const getApplicationsByUser = async (req, res) => {
  try {
    const userId = req.params.userId;
    const applications = await JobApplication.getApplicationsByUser(userId);
    res.send(applications);
  } catch (error) {
    console.error("Error fetching user applications:", error);
    res.status(500).send("Error fetching user applications");
  }
};

// Get applications by job
const getApplicationsByJob = async (req, res) => {
  try {
    const jobId = req.params.jobId;
    const applications = await JobApplication.getApplicationsByJob(jobId);
    res.send(applications);
  } catch (error) {
    console.error("Error fetching job applications:", error);
    res.status(500).send("Error fetching job applications");
  }
};

module.exports = {
  createJobApplication,
  getApplicationsByUser,
  getApplicationsByJob,
};
